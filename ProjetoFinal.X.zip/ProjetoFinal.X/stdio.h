#ifndef STDIO_H
#define	STDIO_H

void printf(char txt[17]);

#endif	/* STDIO_H */

