#include "lcd.h"

void printf(char txt[17]){
 int i;   
    for(i=0;i<17;i++) {
    if (txt[i] == '\0')  {
            return;
    }  
    if (txt[i] == '\n')  {
        lcdCommand(0xC0); // muda para a segunda linha
        continue;
    }     
    lcdChar(txt[i]);
    }
}
